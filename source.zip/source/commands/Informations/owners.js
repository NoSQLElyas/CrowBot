const Discord = require('discord.js');
const { Astroia } = require('../../structures/client');

module.exports = {
    name: "owners",
    description: "Permet de lister la liste des owners.",
    usages: "owners",
    /**
     * 
     * @param {Astroia} client 
     * @param {Astroia} message 
     * @param {Astroia} args 
     * @param {Astroia} commandName 
     * @returns 
     */
    run: async (client, message, args, commandName) => {
        if (!args[0]) {
            let data = await client.db.all();
            let ownerList = data.filter(data => data.ID.startsWith(`owner_`)).length > 0 ? data.filter(data => data.ID.startsWith(`owner_`)).map(entry => `<@${entry.ID.split('_')[1]}>`).join("\n") : "Aucun";

            let embed = new Discord.EmbedBuilder()
                .setColor(client.color)
                .setTitle(await client.lang(`owner.titre`))
                .setDescription(ownerList)
                .setFooter(client.footer);

            message.channel.send({ embeds: [embed] });
                } else {
                    message.channel.send(await client.lang("owner.erreur"));
            
        }
    }
};
