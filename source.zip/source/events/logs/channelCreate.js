const Discord = require('discord.js');

module.exports = {
  name: 'channelCreate',
  run: async (client, newChannel) => {
    const guild = newChannel.guild.id;
    const color = client.db.get(`color_${guild}`) || client.config.default_color;
    let channel = client.db.get(`channellogs_${guild}`);
    if (!channel) return;


    const embed = new Discord.EmbedBuilder()
      .setColor(color)
      .setTitle("Création d'un salon")
      .setDescription(`Le salon <#${newChannel.id}> a été créé.\nConfiguration :`)
      .addFields(
        { name: "Nom :", value: `\`${newChannel.name}\``},
        { name: "Description :", value: `\`${newChannel.topic || 'Aucune'}\``}
      )
      .setTimestamp();

  
    const logChannelId = client.db.get(`channellogs_${guild}`);
    const logChannel = newChannel.guild.channels.cache.get(logChannelId);

    if (logChannel) {
      logChannel.send({ embeds: [embed] });
    }
  },
};
