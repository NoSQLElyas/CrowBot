const Discord = require('discord.js');

module.exports = {
  name: 'channelDelete',
  run: async (client, oldChannel, newChannel) => {
    const guild = oldChannel.guild.id;
    const color = client.db.get(`color_${guild}`) || client.config.default_color;
    let channel = client.db.get(`channellogs_${guild}`);
    if (!channel) return;


      const embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle("Suppression d'un salon")
        .setDescription(`Le salon <#${oldChannel.id}> a été supprimé.`)
        .addFields(
          { name: "Ancienne configuration", value: `Nom: \`${oldChannel.name}\`, Description: \`${oldChannel.topic || 'Aucune'}\`` }
        )
        .setTimestamp();

    
      const logChannelId = client.db.get(`channellogs_${guild.id}`);
      const logChannel = oldChannel.guild.channels.cache.get(logChannelId);

      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    
  },
};
