const db = require('quick.db');
const { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, EmbedBuilder } = require('discord.js');
const ms = require('ms');
const Discord = require('discord.js');

module.exports = {
    name: 'ready',
     /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   */
    run: async (client) => {
        setInterval(async () => {
            const reactKeys = await db.all();
      

            const rolereactKeys = reactKeys.filter(reactKey => reactKey.ID.startsWith('rolereact_'));
        

            for (const reactKey of rolereactKeys) {
            

                const [, guildId] = reactKey.ID.split('_');
            

                const db2 = client.db.get(`rolereact_${guildId}`) || {
                    status: false,
                    role: [],
                    channel: []
                };
            
                

                const rolereactData = client.db.get(`rolereact_${guildId}`);
             

                if (rolereactData) {
                    const guild = client.guilds.cache.get(guildId);
                 

                    if (guild) {
                        const rolereactChannel = guild.channels.cache.get(rolereactData.channel);
                     

                        if (rolereactChannel && rolereactChannel.messages) {
                            const msg = await rolereactChannel.messages.fetch(rolereactData.messageid);
                        
                            const roles = db2?.role.map(roleId => ({
                                value: roleId,
                                label: guild.roles.cache.get(roleId)?.name || "Inconnu",
                            })) || [];
                            

                            if (msg && rolereactChannel && roles) {
                              
                                const embed = new Discord.EmbedBuilder()
                                .setColor("#0000FF")
                                .setTitle('Rôles')
                                .setDescription('Choisissez un ou plusieurs rôle(s) à vous ajouter.') 
                                .setImage('https://cdn.discordapp.com/attachments/1166712265161048094/1178034840466108496/standard.gif?ex=6574ad70&is=65623870&hm=86f58730bc075fc72cfd05a64944d824f437505897e678b0f5d85cf42883b2b9&')      
                                const rowRoleDropdown = new ActionRowBuilder()
                            .addComponents(
                                new StringSelectMenuBuilder()
                                    .setCustomId('rolereact_role_dropdown_' + msg.id)
                                    .setPlaceholder('Faîtes un choix !')
                                    .addOptions(
                                        roles.map(role => new StringSelectMenuOptionBuilder()
                                            .setLabel(role.label)
                                            .setValue(role.value)
                                        )
                                    )
                            );
                        
                   

                        
                        
                            client.on('interactionCreate', async (i) => {
                              if (i.customId === `rolereact_role_dropdown_${msg.id}`) {
                                const rolereactData = client.db.get(`rolereact_${msg.guild.id}`) || { status: false, role: [], channel: [] };
                                const selectedRoles = i.values;
                                rolereactData.messageid = i.message.id;
                                rolereactData.role = db2.role;
                                rolereactData.channel = i.channel.id;
                        
                                client.db.set(`rolereact_${msg.guild.id}`, rolereactData);
                              
                        
                                const member = msg.guild.members.cache.get(i.user.id);
                                const existingRoles = member.roles.cache.filter(role => selectedRoles.includes(role.id));
                        
                                if (existingRoles.size > 0) {
                                
                                  await member.roles.remove(existingRoles);
                                  i.reply({ content: 'Rôles retirés avec succès !', ephemeral: true });
                               
                                } else {
                        
                                  for (const roleId of selectedRoles) {
                                    const role = msg.guild.roles.cache.get(roleId);
                                    if (role) {
                                      await member.roles.add(role);
                                    }
                                  }
                                  i.reply({ content: 'Rôles ajoutés avec succès !', ephemeral: true });
                       
                                }
                              }   
                            });

                               
                                await msg.edit({ embeds: [embed], components: [rowRoleDropdown] });
                         

                                break;
                            } else {
                                console.error('Message ou channel pas trouvé.');
                            }
                        } else {
                            console.error('Channel ou message pas définis.');
                        }
                    } else {
                        console.error('Serveur pas trouvé.');
                    }
                } else {
                    console.error('RoleReactData pas trouvé.');
                }
            }
        }, 10000);
    }
};